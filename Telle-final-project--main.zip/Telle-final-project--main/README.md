# Telle-final-project-

study a machine learning model designed to prevent anti-Semitism.
# Features
* Fetch channels and groups based on a query.
* Store channel details in MongoDB.
* Model Training using DistilBERT 
*  Identify potentially antisemitic messages.
  
# Prerequisites
* Python 3.7+
* MongoDB
* Node.js and npm
* Telegram API credentials - Username, API ID, API Hash (https://my.telegram.org/)

  
# Installation

1. Clone repository:

git clone https://github.com/MyFather123/Telle-final-project-.git

cd Telle-final-project-

2. Libraries:

cd python
      
pip install pandas torch pymongo scikit-learn transformers langdetect telethon transformers[torch] safetensors accelerate

Or

pip install -r requirements.txt

3. backend

cd backend 

npm install

npm install express axios mongodb cors
	
**in case of issues with audit error, run the follow:

npm audit fix --force

4. frontend

cd frontend

npm install

npm install react axios react-router-dom

npm install react react-dom react-router-dom axios bootstrap react-bootstrap normalize.css

npm install --save-dev @babel/plugin-proposal-private-property-in-object

npm install react-scripts@latest

**in case of issues with audit error, run the follow:

npm audit fix --force

5. How to Run
Open 2 cmd sessions - as administrator

Backend: Start Node.js server
cd backend 
node server.js

Frontend: Start the React frontend
cd frontend 
npm start

6. MongoDB Setup

Install and run MongoDB locally.

Verify that diverse_telegram_data_train.csv, diverse_telegram_data_test.csv files located in your repo directory.

Database set up:

Create database named: telegram_data

Create Collection named diverse_telegram_data_train and import the compatible data file diverse_telegram_data_train.csv

Create Collection named  diverse_telegram_data_test and import the compatible data file diverse_telegram_data_test.csv


7. Telegram API Credentials

Option 1: use your credentials.

To create Telegram API credentials, follow these steps:

Go to the Telegram API Development Tools and log in with your Telegram account.

Navigate to the "API development tools" section.

Fill Your Phone Number -> login

Fill in the "App title" and "Short name" fields (these can be anything descriptive for your project).

After submitting, you will receive your API ID and API Hash.

Option 2: ask for using avi/einat/liron API credentials 

Due to security issues, we can not upload our credentials.
