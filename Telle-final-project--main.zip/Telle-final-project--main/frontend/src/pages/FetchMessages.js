import React, { useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card, Spinner} from 'react-bootstrap';
import CustomButton from '../design/CustomButton';  
import AlertMessage from '../design/AlertMessage';  
import CustomInput from '../design/CustomInput';  
import TableChannels from '../design/TableChannels';  
import ModelResult from './ModelResult';
import { useNavigate } from 'react-router-dom';


const FetchMessages = () => {
  const [channelSearchTerm, setChannelSearchTerm] = useState('');
  const [messageSearchTerm, setMessageSearchTerm] = useState('');
  const [messageLimit, setMessageLimit] = useState(50);
  const [alert, setAlert] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isModelLoading, setIsModelLoading] = useState(false);  
  const [modelResults, setModelResults] = useState([]);
  const navigate = useNavigate();
  const [fetchedMessages, setFetchedMessages] = useState([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const initialShowColumns = {
    messageId: true,
    chatName: true,
    messageText: true,
    userId: false,
    chatId: false,
    date: false,
    searchTerms: false,
  };

  const collectionName = "fetch_data";

  const handleFetch = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setAlert(null);

    try {
      const response = await axios.post('http://localhost:5000/api/fetch-messages', {
        user_channel_word: channelSearchTerm,
        user_msg_word: messageSearchTerm,
        message_limit: messageLimit
      });

      console.log('Backend Response:', response.data);

      setAlert({
        message: `Messages fetched successfully!`,
        type: 'success'
      });

      fetchMessagesFromDB();
    } catch (error) {
      setAlert({ message: 'Failed to fetch messages. Please try again.', type: 'danger' });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchMessagesFromDB = async () => {
    setLoadingMessages(true);
    console.log('Fetching messages from collection:', collectionName);

    try {
      const response = await axios.get('http://localhost:5000/api/channels');
      console.log('Response from backend:', response.data);

      if (response.data.length > 0) {
        setFetchedMessages(response.data);
        console.log('Updated fetchedMessages state:', response.data);
      } else {
        setFetchedMessages([]);
        console.warn('No messages found in the collection');
      }
    } catch (error) {
      console.error('Error fetching data from MongoDB:', error);
      setAlert({ message: 'Failed to load messages from the database.', type: 'danger' });
    } finally {
      setLoadingMessages(false);
    }
  };


  const handleRunModel = async () => {
    setIsModelLoading(true);
    try {
        const response = await axios.post('http://localhost:5000/api/run-model');
        setModelResults(response.data.results);
        setAlert({ message: 'Model ran successfully!', type: 'success' });

        // ניווט לדף התוצאות
        navigate('/model-result', { state: { results: response.data.results } });
    } catch (error) {
        setAlert({ message: 'Failed to run model. Please try again.', type: 'danger' });
    } finally {
        setIsModelLoading(false);
    }
  };

  



  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8}>
          <h1 className="text-center mb-4" style={{ color: 'var(--theme-text-color)' }}>
            Fetch Telegram Messages
          </h1>
          {alert && (
            <AlertMessage
              message={alert.message}
              type={alert.type}
              dismissible={true}
              onDismiss={() => setAlert(null)}
            />
          )}
          <Card className="fetch-card mb-4">
            <Card.Body>
              <CustomInput
                label="Enter the Channel Search Term:"
                value={channelSearchTerm}
                onChange={(e) => setChannelSearchTerm(e.target.value)}
                required
              />
              <CustomInput
                label="Enter the Message Search Term:"
                value={messageSearchTerm}
                onChange={(e) => setMessageSearchTerm(e.target.value)}
                required
              />
              <CustomInput
                label="Message Limit:"
                value={messageLimit}
                onChange={(e) => setMessageLimit(e.target.value)}
                type="number"
              />
            </Card.Body>
          </Card>
          <div className="button-container mt-4 mb-4 text-center">
            <CustomButton
              onClick={handleFetch}
              text="Fetch Messages"
              isLoading={isLoading}
              className="fetch-button"
              color="primary"
            />
            <CustomButton
              onClick={fetchMessagesFromDB}
              text="Refresh Table"
              className="refresh-button ml-3"
              color="info"
            />
            <CustomButton
              onClick={handleRunModel}
              text={isModelLoading ? 'Running...' : 'Run Model'}
              isLoading={isModelLoading}
              className="run-model-button ml-3"
              color="warning"
          />
          {modelResults.length > 0 && <ModelResult results={modelResults} />}
          </div>
          {loadingMessages ? (
            <div className="text-center mt-4">
              <Spinner animation="border" />
              <p>Loading messages...</p>
            </div>
          ) : (
            <TableChannels channels={fetchedMessages} initialShowColumns={initialShowColumns} />
          )}
        </Col>
      </Row>
    </Container>
  );
};

export default FetchMessages;