import React, { useState } from 'react';
import { Table, Spinner, Button, Collapse, Form } from 'react-bootstrap';
import theme from '../styles/theme';
import '../styles/table.css';

const TableChannels = ({ channels, initialShowColumns }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [showColumns, setShowColumns] = useState(initialShowColumns);

  const handleToggleColumn = (column) => {
    setShowColumns((prev) => ({
      ...prev,
      [column]: !prev[column],
    }));
  };

  if (!channels || channels.length === 0) {
    return (
      <div className="table-wrapper-container">
        <div style={{ textAlign: 'center', marginTop: '20px' }}>
          <Spinner animation="border" />
          <p>Loading messages or no messages found...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="table-wrapper-container">
      <div className="table-container">
        <Button
          onClick={() => setIsCollapsed(!isCollapsed)}
          aria-controls="column-collapse"
          aria-expanded={isCollapsed}
          variant="secondary"
          className="mb-3"
        >
          Choose Columns to Display
        </Button>
        <Collapse in={isCollapsed}>
          <div id="column-collapse" className="mt-3">
            <Form>
              {Object.keys(showColumns).map((column) => (
                <Form.Check
                  type="checkbox"
                  key={column}
                  id={`checkbox-${column}`}
                  label={column}
                  backgroundColor="secondary"
                  checked={showColumns[column]}
                  onChange={() => handleToggleColumn(column)}
                />
              ))}
            </Form>
          </div>
        </Collapse>

        <Table striped bordered hover style={{ backgroundColor: theme.colors.light }}>
          <thead>
            <tr>
              {showColumns.messageId && <th>Message ID</th>}
              {showColumns.chatName && <th>Chat Name</th>}
              {showColumns.messageText && <th>Message Text</th>}
              {showColumns.userId && <th>User ID</th>}
              {showColumns.chatId && <th>Chat ID</th>}
              {showColumns.date && <th>Date</th>}
              {showColumns.searchTerms && <th>Search Terms</th>}
            </tr>
          </thead>
          <tbody>
            {channels.map((message, index) => (
              <tr key={index}>
                {showColumns.messageId && <td>{message.message_id}</td>}
                {showColumns.chatName && <td>{message.chat_name}</td>}
                {showColumns.messageText && <td>{message.message_text}</td>}
                {showColumns.userId && <td>{message.user_id || 'Unknown'}</td>}
                {showColumns.chatId && <td>{message.chat_id}</td>}
                {showColumns.date && <td>{new Date(message.date).toLocaleString()}</td>}
                {showColumns.searchTerms && (
                  <td>{`${message.search_channel_term} | ${message.search_message_term}`}</td>
                )}
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default TableChannels;